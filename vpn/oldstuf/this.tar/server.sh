#run this on bigboy to be a static vpn server
sudo killall openvpn
sudo openvpn --config /home/sacarlson/vpn/server.conf
sleep  10
